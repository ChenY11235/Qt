#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QToolButton>
#include <QSpinBox>
#include <QLabel>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // 添加编辑菜单
    QMenu *editMenu = ui->menubar->addMenu(tr("编辑(&E)"));

    // 添加打开菜单
    QAction *action_Open = editMenu->addAction(
    QIcon(":/images/fileopen.png"),tr("打开文件(&O)"));

    // 设置快捷键
    action_Open->setShortcut(QKeySequence("Ctrl+O"));

    // 在工具栏中添加动作
    ui->toolBar->addAction(action_Open);

    QToolButton *toolBtn = new QToolButton(this);        // 创建QToolButton
    toolBtn->setText(tr("颜色"));
    QMenu *colorMenu = new QMenu(this);                  // 创建一个菜单
    colorMenu->addAction(tr("红色"));
    colorMenu->addAction(tr("绿色"));
    toolBtn->setMenu(colorMenu);                         // 添加菜单
    toolBtn->setPopupMode(QToolButton::MenuButtonPopup); // 设置弹出模式
    ui->toolBar->addWidget(toolBtn);           // 向工具栏添加QToolButton按钮
    QSpinBox *spinBox = new QSpinBox(this);         // 创建QSpinBox
    ui->toolBar->addWidget(spinBox);            // 向工具栏添加QSpinBox部件
    // 显示临时消息，显示2000毫秒即2秒钟
    ui->statusbar->showMessage(tr("欢迎使用多文档编辑器"), 2000);
    // 创建标签，设置标签样式并显示信息，将其以永久部件的形式添加到状态栏
    QLabel *permanent = new QLabel(this);
    permanent->setFrameStyle(QFrame::Box | QFrame::Sunken);
    permanent->setText("219050729_徐晨宇");
    ui->statusbar->addPermanentWidget(permanent);


}

MainWindow::~MainWindow()
{
    delete ui;
}

