#include "mainwindow.h"

#include <QApplication>
#include <QSplashScreen>
#include <QThread>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QPixmap pixmap(":/images/e.jpg");
    QSplashScreen splash(pixmap);
    splash.show();

    // 模拟应用程序加载过程
    QThread::sleep(2);

    // 加载完成后关闭启动画面
    splash.finish(nullptr);
    MainWindow w;
    w.show();
    return a.exec();
}
